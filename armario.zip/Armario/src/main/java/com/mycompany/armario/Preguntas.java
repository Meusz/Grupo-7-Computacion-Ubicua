/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.armario;

import java.util.ArrayList;

/**
 *
 * @author jesus
 */
public class Preguntas {
    private ArrayList<String> preguntas = new ArrayList<String>();

    public String getPreguntas(int posicion) {
        return preguntas.get(posicion);
    }
    public int getTamaño(){
        return preguntas.size();
    }

    public void añadirPreguntas(String pregunta) {
        preguntas.add(pregunta);
    }
    
    
}
