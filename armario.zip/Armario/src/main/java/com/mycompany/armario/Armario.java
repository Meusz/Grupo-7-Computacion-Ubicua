/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.armario;

import java.util.ArrayList;

/**
 *
 * @author jesus
 */
public class Armario {

    private int capacidad;
    private ArrayList<Ropa> prendas = new ArrayList<Ropa>();

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    public int getTamaño(){
        return prendas.size();
    }

    public Ropa seleccionarRopaPosicion(int posicion) {
        return prendas.get(posicion);
    }

    public Ropa seleccionarRopaArticulo(Ropa articulo) {
        return prendas.get(prendas.indexOf(articulo));
    }

    public int añadirRopa(Ropa articulo) {
        if (prendas.size()+1 <= capacidad){
            prendas.add(articulo); 
            return 1;
        }
        else{
            System.out.println("Armario ya esta lleno, vacie antes de meter mas prendas");
            return 0;
        }
    }

    public void eliminarRopa(Ropa articulo) {
        prendas.remove(articulo);
    }
}
