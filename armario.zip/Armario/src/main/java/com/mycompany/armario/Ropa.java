/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.armario;

/**
 *
 * @author jesus
 */
public class Ropa {
    
    private String color;
    private int posicion;
    private String tipo;

    public Ropa(String color, String tipo) {
        this.color = color;
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }


    public String getColor() {
        return color;
    }


}
